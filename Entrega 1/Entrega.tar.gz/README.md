Brainiax
========

Proyecto de la Materia Traductores e Interpretadores con el cual se requiere realizar un lexer para "comprender" el
lenguaje Brainiax.

----------------------------

Para la realizacion de este proyecto se estara usando Python, con la herramienta PLY.

Observaciones:
----------------------------
Para poder guardar el 0 frente a un numero se tuvo que guardar los numeros como string. Para que este no convirtiera el numero a un entero.


Problemas que presenta:
----------------------------

Actualmente presenta un problema con el caracter "~" , lo identifica como un '='  
